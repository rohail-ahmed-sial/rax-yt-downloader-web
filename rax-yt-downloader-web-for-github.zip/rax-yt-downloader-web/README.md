# RAX YT Downloader (web)

A small website that saves YouTube videos as MP4 and their sound as MP3. It runs on your own computer, and phones on the same Wi-Fi can use it too.

![A video loaded on the site, with a download in progress](docs/preview-desktop.png)

## What it does

- Paste a link and pick a quality: MP4 from 144p up to 4K, with the file size for each.
- Save just the sound as MP3 (128, 192 or 320 kbps) or M4A, with the title and cover art added.
- Download the thumbnail or the subtitles (as SRT).
- Open a whole playlist or channel, untick what you don't want, and save the rest in one go.
- Follow progress, speed and time left in the downloads panel. Finished files land in your browser's Downloads folder.

## Ways to start a download

| Way | How |
| --- | --- |
| Paste | Copy a link and press **Paste** on the site, or Ctrl+V. It loads by itself. |
| Swap the address | On any YouTube page, change `youtube.com` in the address bar to `localhost:5000` and press Enter. |
| One-click button | Drag the yellow **Get with RAX** button onto your bookmarks bar, then click it while watching any video. |
| Drag and drop | Drag a link from another tab onto the page. |
| Many links | Paste a whole list of links at once and download them together. |
| Phone | Join the same Wi-Fi and open the phone address the site shows, such as `192.168.1.5:5000`. |

<img src="docs/preview-phone.png" alt="The site on a phone: the home screen, and quality choices with the downloads panel" width="560">

## Getting started (Windows)

1. Install [Python 3.10 or newer](https://www.python.org/downloads/). On the installer's first screen, tick **Add python.exe to PATH**.
2. Download this repo with **Code > Download ZIP**, then unzip it.
3. Double-click **START.bat**.

The first start takes a few minutes while it installs the download engine. Then your browser opens http://localhost:5000. Keep the black window open while you use the site, and close it when you're done.

`START.bat` updates the download engine every time it starts, because YouTube changes often and a fresh engine fixes most download problems.

### Mac or Linux

```bash
python3 -m venv .venv
.venv/bin/pip install -U -r requirements.txt
.venv/bin/python server.py
```

## How it works

- `website/` is the site itself: plain HTML, CSS and JavaScript, with no build step.
- `server.py` is a small [Flask](https://flask.palletsprojects.com/) server. It serves the site, looks up videos and runs the downloads with [yt-dlp](https://github.com/yt-dlp/yt-dlp).
- [FFmpeg](https://ffmpeg.org/) joins HD video with its sound and makes the MP3s. It comes from the `imageio-ffmpeg` package, an `ffmpeg` folder next to `server.py`, or an FFmpeg already installed on your computer.
- [Deno](https://deno.com/) is the JavaScript runtime YouTube downloads now need. It comes from the `deno` package. Node.js 20 or newer also works if it's installed.

Downloads go to `temp_downloads/` first, then to your browser. The server clears them out after 30 minutes.

## Settings

The settings sit at the top of `server.py`:

| Setting | Default | What it does |
| --- | --- | --- |
| `PORT` | `5000` | The address port. If it's busy, the next free one is used. |
| `ALLOW_PHONES_ON_WIFI` | `True` | Lets phones and laptops on your Wi-Fi use the site. |
| `MAX_PARALLEL_DOWNLOADS` | `2` | How many videos download at the same time. |
| `KEEP_FILES_MINUTES` | `30` | How long finished files wait before they're deleted. |
| `MAX_PLAYLIST_VIDEOS` | `500` | The biggest playlist the site will list. |

## Troubleshooting

- **Lots of videos suddenly fail:** close the black window and run `START.bat` again to update the engine.
- **Age-restricted videos:** export your YouTube cookies with the "Get cookies.txt LOCALLY" browser extension, save the file as `cookies.txt` next to `server.py`, and restart. It can sign in to your account, so never share it. It's listed in `.gitignore`, so it won't be committed by accident.
- **The phone can't connect:** check that both devices are on the same Wi-Fi, and allow Python through Windows Firewall when it asks.

## Hosting

The site needs Python and FFmpeg running next to it, so ordinary PHP web hosting can't run it. It's built to run on your own computer.

## Please note

Download only videos you own or have permission to save. This project isn't affiliated with YouTube or Google.

Made by [Rohail Ahmed](https://github.com/rohail-ahmed-sial).
